<?php
$conn = new mysqli("localhost", "root", "", "job_allocation");
if ($conn->connect_error) {
  die(json_encode(["success" => false, "message" => "DB connection failed"]));
}

$group_id = intval($_GET['group_id'] ?? 0);
$members = [];

$sql = "SELECT u.username 
        FROM users u
        JOIN group_members gm ON gm.user_id = u.id
        WHERE gm.group_id = $group_id";

$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    $members[] = $row['username'];
  }
  echo json_encode(["success" => true, "members" => $members]);
} else {
  echo json_encode(["success" => false, "message" => "No members found"]);
}
?>
