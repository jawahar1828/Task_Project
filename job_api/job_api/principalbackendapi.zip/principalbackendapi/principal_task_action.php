<?php
header('Content-Type: application/json');

$servername = "localhost";
$username   = "root";
$password   = "";
$database   = "job_allocation";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
  echo json_encode(['success' => false, 'message' => 'Connection failed']);
  exit;
}

$task_id      = $_POST['task_id'];
$recipient_id = $_POST['recipient_id'];
$status       = $_POST['status'];
$reason       = $_POST['reason'] ?? '';

$update_status = "UPDATE task_recipients SET status = '$status' WHERE id = $recipient_id AND task_id = $task_id";

if ($conn->query($update_status)) {
  // ✅ If Reassign, store comment in tasks table
  if ($status === "Pending") {
    $safe_reason = $conn->real_escape_string($reason);
    $conn->query("UPDATE tasks SET comment = '$safe_reason' WHERE id = $task_id");
  }

  echo json_encode(['success' => true, 'message' => "Status updated to $status"]);
} else {
  echo json_encode(['success' => false, 'message' => "Failed to update status"]);
}

$conn->close();
?>
